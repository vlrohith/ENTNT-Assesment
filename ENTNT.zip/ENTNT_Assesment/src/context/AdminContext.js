import React, { createContext, useState } from "react";

export const AdminContext = createContext();

const AdminProvider = ({ children }) => {
  const [companies, setCompanies] = useState([]);
  const [communicationMethods, setCommunicationMethods] = useState([]);

  const addCompany = (company) => {
    setCompanies([...companies, company]);
  };

  const addCommunicationMethod = (method) => {
    setCommunicationMethods([...communicationMethods, method]);
  };

  return (
    <AdminContext.Provider
      value={{ companies, addCompany, communicationMethods, addCommunicationMethod }}
    >
      {children}
    </AdminContext.Provider>
  );
};

export default AdminProvider;
