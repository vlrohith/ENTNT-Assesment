import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import AdminProvider from "./context/AdminContext";
import AdminDashboard from "./pages/AdminDashboard";
import UserDashboard from "./pages/UserDashboard";

const App = () => {
  return (
    <AdminProvider>
      <Router>
        <Routes>
          <Route path="/admin" element={<AdminDashboard />} />
          <Route path="/user" element={<UserDashboard />} />
        </Routes>
      </Router>
    </AdminProvider>
  );
};

export default App;
