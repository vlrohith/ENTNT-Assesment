import React from "react";
import CompanyForm from "../components/Admin/CompanyForm";
import CompanyList from "../components/Admin/CompanyList";
import CommunicationMethodForm from "../components/Admin/CommunicationMethodForm";
import CommunicationMethodList from "../components/Admin/CommunicationMethodList";

const AdminDashboard = () => {
  return (
    <div>
      <h1>Admin Dashboard</h1>
      <CompanyForm />
      <CompanyList />
      <CommunicationMethodForm />
      <CommunicationMethodList />
    </div>
  );
};

export default AdminDashboard;
