import React from "react";

const UserDashboard = () => {
  return (
    <div>
      <h1>User Dashboard</h1>
      <p>This is where users will manage their communications and view the calendar.</p>
      {/* Placeholder for additional features like notifications, calendar, etc. */}
    </div>
  );
};

export default UserDashboard;
