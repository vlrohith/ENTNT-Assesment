import React, { useState, useContext } from "react";
import { AdminContext } from "../../context/AdminContext";

const CommunicationMethodForm = () => {
  const { addCommunicationMethod } = useContext(AdminContext);
  const [formData, setFormData] = useState({
    name: "",
    description: "",
    sequence: 1,
    mandatory: false,
  });

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData({
      ...formData,
      [name]: type === "checkbox" ? checked : value,
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    addCommunicationMethod(formData);
    setFormData({ name: "", description: "", sequence: 1, mandatory: false });
  };

  return (
    <form onSubmit={handleSubmit}>
      <input
        type="text"
        name="name"
        value={formData.name}
        onChange={handleChange}
        placeholder="Communication Method Name"
        required
      />
      <input
        type="text"
        name="description"
        value={formData.description}
        onChange={handleChange}
        placeholder="Description"
        required
      />
      <input
        type="number"
        name="sequence"
        value={formData.sequence}
        onChange={handleChange}
        placeholder="Sequence"
        min="1"
        required
      />
      <label>
        Mandatory:
        <input
          type="checkbox"
          name="mandatory"
          checked={formData.mandatory}
          onChange={handleChange}
        />
      </label>
      <button type="submit">Add Communication Method</button>
    </form>
  );
};

export default CommunicationMethodForm;
