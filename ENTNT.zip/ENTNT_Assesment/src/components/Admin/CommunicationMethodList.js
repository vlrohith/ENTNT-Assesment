import React, { useContext } from "react";
import { AdminContext } from "../../context/AdminContext";

const CommunicationMethodList = () => {
  const { communicationMethods } = useContext(AdminContext);

  return (
    <div>
      <h2>Communication Methods</h2>
      {communicationMethods.length === 0 ? (
        <p>No communication methods added yet.</p>
      ) : (
        <table border="1">
          <thead>
            <tr>
              <th>Name</th>
              <th>Description</th>
              <th>Sequence</th>
              <th>Mandatory</th>
            </tr>
          </thead>
          <tbody>
            {communicationMethods.map((method, index) => (
              <tr key={index}>
                <td>{method.name}</td>
                <td>{method.description}</td>
                <td>{method.sequence}</td>
                <td>{method.mandatory ? "Yes" : "No"}</td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
};

export default CommunicationMethodList;
