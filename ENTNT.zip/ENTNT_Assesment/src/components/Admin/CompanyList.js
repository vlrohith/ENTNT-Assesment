import React, { useContext } from "react";
import { AdminContext } from "../../context/AdminContext";

const CompanyList = () => {
  const { companies } = useContext(AdminContext);

  return (
    <div>
      <h2>Company List</h2>
      {companies.length === 0 ? (
        <p>No companies added yet.</p>
      ) : (
        <table border="1">
          <thead>
            <tr>
              <th>Name</th>
              <th>Location</th>
              <th>LinkedIn</th>
              <th>Emails</th>
              <th>Phone Numbers</th>
              <th>Comments</th>
              <th>Periodicity</th>
            </tr>
          </thead>
          <tbody>
            {companies.map((company, index) => (
              <tr key={index}>
                <td>{company.name}</td>
                <td>{company.location}</td>
                <td>
                  <a href={company.linkedin} target="_blank" rel="noopener noreferrer">
                    LinkedIn Profile
                  </a>
                </td>
                <td>{company.emails}</td>
                <td>{company.phoneNumbers}</td>
                <td>{company.comments}</td>
                <td>{company.periodicity}</td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
};

export default CompanyList;
