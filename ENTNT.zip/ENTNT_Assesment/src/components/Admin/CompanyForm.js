import React, { useState, useContext } from "react";
import { AdminContext } from "../../context/AdminContext";

const CompanyForm = () => {
  const { addCompany } = useContext(AdminContext);
  const [formData, setFormData] = useState({
    name: "",
    location: "",
    linkedin: "",
    emails: "",
    phoneNumbers: "",
    comments: "",
    periodicity: "2 weeks",
  });

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    addCompany(formData);
    setFormData({
      name: "",
      location: "",
      linkedin: "",
      emails: "",
      phoneNumbers: "",
      comments: "",
      periodicity: "2 weeks",
    });
  };

  return (
    <form onSubmit={handleSubmit}>
      <input
        type="text"
        name="name"
        value={formData.name}
        onChange={handleChange}
        placeholder="Company Name"
        required
      />
      <input
        type="text"
        name="location"
        value={formData.location}
        onChange={handleChange}
        placeholder="Location"
      />
      <input
        type="url"
        name="linkedin"
        value={formData.linkedin}
        onChange={handleChange}
        placeholder="LinkedIn Profile"
      />
      <input
        type="email"
        name="emails"
        value={formData.emails}
        onChange={handleChange}
        placeholder="Emails"
      />
      <input
        type="text"
        name="phoneNumbers"
        value={formData.phoneNumbers}
        onChange={handleChange}
        placeholder="Phone Numbers"
      />
      <textarea
        name="comments"
        value={formData.comments}
        onChange={handleChange}
        placeholder="Comments"
      />
      <select name="periodicity" value={formData.periodicity} onChange={handleChange}>
        <option value="1 week">1 Week</option>
        <option value="2 weeks">2 Weeks</option>
        <option value="1 month">1 Month</option>
      </select>
      <button type="submit">Add Company</button>
    </form>
  );
};

export default CompanyForm;
